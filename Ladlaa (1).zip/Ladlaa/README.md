pkg update

pkg upgrade

pkg install python

pkg install python2

pkg install git

pip2 install requests

pip2 install mechanize

git clone https://github.com/HanifLadla/Ladlaa

cd Ladlaa

python2 Ladlaa.py

username:(Hanif)

password:(Ladlaa)


