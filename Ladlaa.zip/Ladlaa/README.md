pkg update

pkg upgrade

pkg install python

pkg install python2

pkg install git

pip2 install requests

pip2 install mechanize

git clone https://github.com/hearthackerBabar/Huntter/

cd Huntter

python2 Hunt404.py

username:(Facebook)

password:(Huntter)


